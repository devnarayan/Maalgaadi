<?php
/**
 * Database config variables
 */
 /*
$host = $_SERVER['HTTP_HOST'];
             $hostname = 'localhost';
            $database = 'maalgaad_maalgaadinew';
            $username = 'maalgaad_vipul';
            $password = 'newtest@123';
        define("DB_HOST", $hostname);
define("DB_USER", $username);
define("DB_PASSWORD", $password);
define("DB_DATABASE", $database);

*/
$host = $_SERVER['HTTP_HOST'];
$hostname = 'localhost';
$database = 'maalgaad_maalgaadinew';
$username = 'maalgaad_vipul';
$password = 'newtest@123';
define("DB_HOST", $hostname);
define("DB_USER", $username);
define("DB_PASSWORD", $password);
define("DB_DATABASE", $database);
/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyBIkQyG2nXYEVIOt3cce94TEdWDVuBG7MY"); // Place your Google API Key
?>