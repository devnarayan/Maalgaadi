<?php
include '../includes/define.php';
include_once './GCM.php';
$mode = $_GET['mode'];
unset($_GET['mode']);
switch ($mode) {
    case "accept":
        $data = array_merge($_POST, json_decode(file_get_contents('php://input'), true));
        $_POST = $data[0];
        if ((isset($_POST)) && (!empty($_POST))) {
            $today = date("Y-m-d H:i:s");
            $_POST['accept_time'] = $today;
            $arr['accept_time'] = $_POST['accept_time'];
            $arr['driver_id'] = $_POST['driver_id'];
            $arr['vehicle_id'] = $_POST['vehicle_id'];
            $arr['id'] = $_POST['booking_id'];
            $booking_id = $_POST['booking_id'];
            $arr['status'] = 2;
            $vehicle = $_POST['vehicle_id'];
            $result1 = $objConnect->selectWhere('booking', "id=$booking_id and (status<2 or status=33 or status=34 or status=93)");
            $num1 = $objConnect->total_rows();
            if ($num1) {
                
                $row1 = $objConnect->fetch_assoc();
                $sql4 = "select vehicle.category,vehicle.registration_no,vehicle.mobile_no, driver.name from vehicle left join login on login.vehicle_id=vehicle.id and login.status=1  left join driver on driver.id=login.driver_id where vehicle.id=$vehicle ";
                $result4 = mysql_query($sql4) or die(mysql_error());
                $row4 = mysql_fetch_assoc($result4);
                $brr['status'] = 0;
                $result2 = $objConnect->update("vehicle", $brr, "id=$vehicle");
                $crr['status'] = 0;
                $crr['closer_id'] = $_POST['driver_id'];
                $crr['closetime'] = date("Y-m-d H:i:s");
                $crr['vehicle_id'] = $_POST['vehicle_id'];
                $crr['driver_id'] = $_POST['driver_id'];
                $objConnect->update("notification", $crr, "booking_id=$booking_id and (booking_status=1 || booking_status=0 ||  booking_status=33 ||  booking_status=93) and status=1");
                $xrr['status'] = 0;
                $objConnect->update("logout", $xrr, "booking_id=$booking_id and status=1");
                $result = $objConnect->update('booking', $arr, "id=$booking_id");
                $mobileno = $row1['phone'];
                $message = "Booking for ID  " . sprintf("%07d", $arr['id']) . " confirmed. Your vehicle " . $row4['registration_no'] . " With driver " . $row4['name'] . " " . $row4['mobile_no'] . "  will reach the source as scheduled. Thank you.";
                $senderid = "101010";
                sendsms($mobileno, $message, $senderid);
                $output['status'] = "200";
                $output['message'] = "Booking succefully accepted";
                print(json_encode($output));
               
            } else {
                $result1 = $objConnect->selectWhere('booking', "id=$booking_id");
                $row1 = mysql_fetch_array($result1);
                if ($row1['status'] == 2 && $row1['vehicle_id'] == $_POST['vehicle_id']) {
                    $output['status'] = "200";
                    $output['message'] = "Booking succefully accepted";
                    print(json_encode($output));
                } else {
                    $output['status'] = "404";
                    $output['message'] = "Booking already assigned";
                    print(json_encode($output));
                }
            }
        } else {
            $output['status'] = "500";
            $output['message'] = "No Data Recieved in Request";
            print(json_encode($output));
        }
        break;
    case "rebooking":
        $data = array_merge($_POST, json_decode(file_get_contents('php://input'), true));
        $_POST = $data[0];
        if ((isset($_POST)) && (!empty($_POST))) {
            $vehicle = $_POST['vehicle_id'];
            $booking_id = $_POST['booking_id'];
            $result1 = $objConnect->selectWhere('booking', "id=$booking_id and vehicle_id=$vehicle");
            $num1 = $objConnect->total_rows();
            if ($num1) {
                $row2 = $objConnect->fetch_assoc();
                $row2['pickup_name'] = $row2['pick_up_name'];
                $row2['pickup_number'] = $row2['pick_up_no'];
                $row2['pickup_organization'] = $row2['pick_up_organization'];
                $result3 = $objConnect->selectWhere("vehicle", "id='$vehicle'");
                $row3 = $objConnect->fetch_assoc();
                $regId = $row3["device_token"];
                $data1['result'][0]['data'] = $row2;
                $message = json_encode($data1);
                $gcm = new GCM();
                $registatoin_ids = array($regId);
                $message = array("booking" => $message);
                 $output['status'] = "200";
                $output['message'] = "Booking done ";
                print(json_encode($output));
               // print_r($message);
                sleep(20);
                
                $result = $gcm->send_notification($registatoin_ids, $message);
            } else {
                $output['status'] = "404";
                $output['message'] = "Booking Does Not belong to you";
                print(json_encode($output));
            }
        } else {
            $output['status'] = "500";
            $output['message'] = "No Data Recieved in Request";
            print(json_encode($output));
        }
        break;
    case "decline":
        $data = array_merge($_POST, json_decode(file_get_contents('php://input'), true));
        $_POST = $data[0];
        if ((isset($_POST)) && (!empty($_POST))) {
            $today = date("Y-m-d H:i:s");
            $_POST['decline_time'] = $today;
            $arr['driver_id'] = $_POST['driver_id'];
            $arr['vehicle_id'] = $_POST['vehicle_id'];
            $arr['booking_id'] = $_POST['booking_id'];
            $arr['decline_time'] = $today;
            $arr['status'] = 1;
            $result = $objConnect->insert('declines', $arr);
            if ($result) {
                $output['status'] = "200";
                $output['message'] = "Booking Declined ";
                print(json_encode($output));
            } else {
                $output['status'] = "404";
                $output['message'] = "Can not save Record ";
                print(json_encode($output));
            }
        } else {
            $output['status'] = "500";
            $output['message'] = "No Data Recieved in Request";
            print(json_encode($output));
        }
        break;
    case "completeBooking":
        $message=file_get_contents('php://input');
        $sql="insert into requests values('','$message','".date("Y-m-d h:i:s")."','complete booking',1)";
        mysql_query($sql) or die(mysql_error());
        $data = array_merge($_POST, json_decode(file_get_contents('php://input'), true));
        
        if ((isset($data)) && (!empty($data))) {
            foreach ($data as $key1 => $value1) {
                //send message
                $_POST = $value1;

                $booking_id = $_POST['booking_id'];
                $logs = $_POST['logs'];
                // $objConnect->deleteRow("booking_logs","booking_id=$booking_id");
                $result7 = $objConnect->selectWhere("booking", "id=$booking_id");
                $row7 = $objConnect->fetch_assoc();
                foreach ($logs as $value) {
                    unset($value['booking_logs_id']);
                    unset($value['sync_status']);
                    unset($value['id']);

                    if ($value['status'] == "reached to customer") {
                        $borr['pickup_lat'] = $value['current_latitude'];
                        $borr['pickup_lng'] = $value['current_longitude'];
                        $borr['pick_up_landmark'] = getAddress($value['current_latitude'], $value['current_longitude']);
                        $objConnect->update("booking", $borr, "id=$booking_id");
                        $borr['status'] = 1;
                        $objConnect->update("favorite_location", $borr, "status=0 and current_location like '" . mysql_real_escape_string($row7['current_location']) . "' and customer_id='" . $row7['customer_id'] . "'");
                    } elseif ($value['status'] == "stop unloading") {
                        $corr['drop_lat'] = $value['current_latitude'];
                        $corr['drop_lng'] = $value['current_longitude'];
                        $corr['drop_landmark'] = getAddress($value['current_latitude'], $value['current_longitude']);
                        $borr['pickup_lat'] = $value['current_latitude'];
                        $borr['pickup_lng'] = $value['current_longitude'];
                        $borr['pick_up_landmark'] = getAddress($value['current_latitude'], $value['current_longitude']);
                        $objConnect->update("booking", $corr, "id=$booking_id");
                        $borr['status'] = 1;
                        $objConnect->update("favorite_location", $borr, "status=0 and current_location like '" . mysql_real_escape_string($row7['drop_location']) . "' and customer_id='" . $row7['customer_id'] . "'");
                    }

                    $value['datetime'] = changeFormat("d:M:Y:H:i:s", "Y-m-d H:i:s", $value['datetime']);
                    $result2 = $objConnect->insert("booking_logs", $value);
                }
                unset($_POST['short']['bookingshort_id']);
                unset($_POST['short']['id']);

                //$objConnect->deleteRow("booking_short","booking_id=$booking_id");

                $result2 = $objConnect->insert("booking_short", $_POST['short']);
                $xrr['status'] = 7;
                $result3 = $objConnect->update("booking", $xrr, "id=$booking_id");
                $output['status'] = "200";
                $result7 = $objConnect->selectWhere("booking", "id=$booking_id");
                $row7 = $objConnect->fetch_assoc();
                unset($brr);
                $vrr['status'] = 1;
                $resultvehi = $objConnect->update("vehicle", $vrr, "id='" . $row7['vehicle_id']."'");
                $brr['booking_id'] = $booking_id;
                $brr['trip_time'] = $_POST['short']['trip_time'];
                $brr['trip_distance'] = $_POST['short']['trip_distance'];
                $brr['rate'] = $row7['rate'];
                $brr['payment'] = $_POST['short']['payment'];
                $brr['addedon'] = date("Y-m-d H:i:s");
                $result2 = $objConnect->insert("payment", $brr);
                $mobileno = $row7['phone'];
                $message = "The consignment booked through " . sprintf("%07d", $booking_id) . " has been successfully delivered. An amount of Rs. " . $_POST['short']['payment'] . "  has been duly received by driver. Thank you for choosing MaalGaadi.";
                $senderid = "101010";
                sendsms($mobileno, $message, $senderid);
                unset($_POST);
            }
            print(json_encode($output));
        } else {
            $output['status'] = "500";
            $output['message'] = "No Data Recieved in Request";
            print(json_encode($output));
        }
        break;
    case "canceldetail":
        $data = array_merge($_POST, json_decode(file_get_contents('php://input'), true));
        $_POST = $data[0];
        if ((isset($_POST)) && (!empty($_POST))) {
            $booking_id = $_POST['booking_id'];
            $_POST['datetime'] = changeFormat("d:M:Y:H:i:s", "Y-m-d H:i:s", $_POST['datetime']);
            $objConnect->insert("reassigndetail", $_POST);
            $arr['status'] = 34;
            $result2 = $objConnect->update('booking', $arr, "id=$booking_id");
            $output['status'] = "200";
            $output['message'] = "Booking Canceled";
            print(json_encode($output));
        } else {
            $output['status'] = "500";
            $output['message'] = "No Data Recieved in Request";
            print(json_encode($output));
        }
        break;
    default:
        break;
}
?>